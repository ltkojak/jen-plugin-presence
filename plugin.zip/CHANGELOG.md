# Presence Plugin — Changelog

## [1.2.3] - 2026-10-07

Requires Jen 5.68.0 (a 5.68.0 beta satisfies it); the constant this release uses is exported by Jen 5.68.0-beta.18 and later.

### Fixed: which leases count as current

Three queries - a tracked device's current address and hostname, the neighbour pass's lease list, and the other-lease check - asked for `state=0` (two of them without any expiry test), so a lease that had already ended still gave a device an address and kept it looking local. All four lease queries in the plugin now use Jen's one definition of a current lease, `ACTIVE_LEASE4` (state 0 AND not past its expiry), exported through `jen.plugin_api` instead of each spelling it; the harness proves each asks for it and that the plugin never spells the predicate itself.

## [1.2.2] - 2026-10-07

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: judging a tracked device and writing it are one transaction

*Track*, *relabel*, *move* and *untrack* each read the row on one connection, judged its owner subnet, and wrote on another. A device
another admin tracked, moved or removed in the moment between the two was relabelled by the `INSERT ... ON DUPLICATE KEY UPDATE`, moved by
an `UPDATE ... WHERE mac=...` or deleted by a `DELETE ... WHERE mac=...` that carried no owner condition at all. Each now runs on one
connection: the row is read `FOR UPDATE` (nobody else can change or create it until the request ends), judged, and written with the judged
owner as a predicate (`subnet_id <=> owner`) and the count checked. A row that is no longer the one that was judged refuses with *That device
changed while you were saving it — nothing was changed* and audits nothing. A new device is a plain `INSERT`: if another request created it
first (duplicate key, or a deadlock between two inserts of one MAC) the row that won is locked and judged again, and a row in a subnet the
caller cannot see is refused, never relabelled. Not being able to reach the database at all counts as a failed lookup, as 1.2.1 had it.

### Fixed: the online/offline event carried no subnet

`plugin.presence.transition` was written with no subnet, so it appeared only to unrestricted viewers: the account that owns a tracked device
never saw it go online or offline in Timeline. It now carries the device's owner subnet (a device with no owner subnet stays
unrestricted-only).

## [1.2.1] - 2026-10-07

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: a failed existence lookup is no longer read as "no such device"

Tracking, untracking and moving a device start by looking up whether it is already tracked, and the answer decides who may touch
it. That lookup returned `None` both when there was no such row and when the SELECT itself failed, so with the database failing for
that one statement `track` carried on as if the device were new, judged it on the client's current subnet, and its upsert relabelled a
row owned by a subnet the caller cannot see. The lookup now has three outcomes (found, not found, failed): on a failure the route
flashes *Could not check the existing record — nothing was changed*, logs, writes nothing and audits nothing. The same applies to
untrack and move.

### Changed: the module's design notes state the stored-object contract

The "who may do what" paragraph at the top of the file still said a tracked device belongs to the subnet its MAC is in now. It now
says what 1.2.0 made true (the owner subnet, a Move, the current subnet derived and shown only in scope) and points at the plugins
documentation as the source.

## [1.2.0] - 2026-10-06

A changed contract, so a minor release; no schema change and `requires_jen` stays 5.68.0. The `subnet_id` column of `pr_tracked`
keeps its name and now means one thing: the **owner subnet** of the tracking.

### Changed: a tracked device's subnet no longer follows the client

Presence had two contradictory ideas about `pr_tracked.subnet_id`. 1.1.1 judged the Investigation card on it as a stored subnet
(who may see this tracking), while every lease event rewrote it to the client's current subnet, so a device tracked in subnet B
was handed to subnet A by its next lease and its label and state became visible to a caller scoped to A: the "stored" subnet
*was* the current one. The two are now separate. The column is the owner subnet: written when the device is tracked, changed
only by an explicit move, never by a lease event (`_refresh_subnet` is gone; a lease event updates state only). The page, relabel,
untrack, the stored state and the Investigation card all judge on it. Where the device is now is derived when the page is read and
shown as *now in …* only to a caller who may see that subnet.

### Added: Move, the one way to change the owner subnet

An admin who can see both the subnet a device is filed under and the subnet it is going to can move it from the tracked-device
list; the move is audited with both subnet ids. A device filed under a subnet the caller cannot see is *not found* for them, a
target the caller cannot see (or Jen does not know) is refused, and relabelling a tracked device never changes its subnet.
Devices that had followed a client before this release keep the subnet they have; one that should belong somewhere else is moved
by hand.

### Fixed: the neighbour pass asks where the device is now

Whether a tracked device is on a segment the Jen host is attached to (and so can be seen in its neighbour table) is judged on its
current address, then its current subnet, and only last on the owner subnet, which no longer follows it.

## [1.1.1] - 2026-10-06

Fix to the investigation provider added in 1.1.0. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: a tracked device is judged by the subnet it was tracked in, not by where the client is now

1.1.0 judged the Investigation card by the subnet the MAC is in now, falling back to the tracked row's own. A tracked
device is stored data, and the question for stored data is where it was stored: a device tracked in subnet B (its label,
its state, and, to an admin, the sinks it is published to) was shown to a caller scoped to subnet A as soon as the
client's lease moved to A. A tracked row is now judged by its own stored subnet, and a row with no subnet is for an
unrestricted caller only. Where the client is now is shown on the card as **Now in** when the caller may see that subnet —
only ever as a fact, and never named when it is a subnet the caller cannot see.

## [1.1.0] - 2026-10-04

Requires Jen 5.68.0 (a 5.68.0 beta satisfies it): this release registers an **investigation provider**.

### Added: state, last seen and where it is published, on Jen's Investigation page

Jen's Investigation page (`/client`) now has a "What else Jen knows" section on its Overview, and this plugin
contributes one card to it for a tracked client: whether it is online or offline, since when or last seen when, and —
to an admin only, since sinks are an admin's — the names of the enabled sinks its state is published to (names only,
never an address or a credential). A client that is not tracked adds no card.

The card is judged on the subnet the MAC is in now (Jen's one precedence), falling back to the subnet stored on its
tracked row, so a client that moved out of a restricted caller's subnets stops showing; a client outside the caller's
scope — or in no subnet, for a restricted caller — gets nothing. `requires_jen` moves to 5.68.0 because the hook does
not exist before it.

## [1.0.4] - 2026-09-27

Jen's new system scenario 13 (Q101 c) runs Presence against a real eclipse-mosquitto broker over
plain and TLS listeners for the first time — every prior check of the MQTT client was structural
(byte-range assertions against the OASIS spec), never against a real broker's actual behaviour
end to end. Found reading the send path while building that scenario, ahead of the dispatch
itself:

### Fixed: a sink's last_error never cleared once set

A failed send recorded the failure on the sink (`last_error`), but nothing ever cleared it on a
later successful one — a broker that had gone down and come back kept showing its old failure on
the Presence page indefinitely, with no way to tell "still down" from "recovered five minutes
ago" from "recovered a week ago". Every send that does not raise now clears the sink's
`last_error`.

### Changed

- `tools/test_plugin.py` checks a failed send records the error and does NOT clear it, and a
  following successful send does.

## [1.0.3] - 2026-09-27

Jen's Q100 sweep: onto Jen 5.65.10's shared helpers, and the sink-publish path moved off Jen's
own shared event-dispatcher thread.

### Fixed: an unreachable sink stalled every other plugin's event handling

`_apply_transition` — called from `_on_lease_event`, which runs directly on Jen's shared
event-dispatcher thread — sent to every enabled sink synchronously: up to 10 seconds per HTTP
sink, or 10 seconds plus a TLS handshake and a CONNACK round trip per MQTT sink, once per
transition. One unreachable broker stalled DNS Sync's own subscriber and every later event behind
it, and a lease storm risked overflowing the dispatcher's 1000-event queue — exactly what
`plugins/README.md` warns a subscriber must never do. Publishing now goes to the plugin's own
single worker thread, started lazily on the first transition (never at `register()`, which stays
pure) with a bounded queue; a burst that outruns it drops the newest update and logs, rather than
blocking the dispatcher.

### Fixed: the Send-test button could report a real bug as "Test failed"

`test_sink` caught any `Exception` from `_send_to_sink` and flashed it as a connectivity failure —
indistinguishable from an actual bug elsewhere in the plugin (a malformed sink row, say), which
would then look like a broker problem to a superadmin and never get reported. The except is
narrowed to `_PresenceError`, the type every sink transport actually raises for a real send
failure; anything else is a bug and now surfaces as one. `_mqtt_publish`'s own connect call had
been outside its `try` — a refused or unreachable broker raised a bare `OSError` past that except
entirely — so it is inside now, same as every other MQTT failure.

### Fixed: two smaller findings from the same audit

- `_current_ip_hostname` selected a lease with no expiry check and no ordering — the same
  omission `_has_active_lease` already guards against. It now applies the same rule (`state=0 AND
  expire > NOW()`), newest lease first.
- `add_sink` stored `topic_prefix` unvalidated: `#` and `+` are MQTT wildcard characters illegal
  in a PUBLISH topic, and some brokers disconnect a client that sends one; a value containing
  either, or a space, is refused now.
- `_existing_tracked` had no exception handling around its database read at all; a failure now
  degrades to "no existing row" (never more permissive — `_track` re-derives the subnet from the
  MAC's current lease/reservation) instead of propagating uncaught.

### Changed

- The MAC check delegates to Jen's shared `normalize_mac()`.
- `_local_macs` (behind the neighbour pass and every page render of the tracked list) reads every
  tracked MAC's current lease in ONE query instead of one per MAC.
- `tools/test_plugin.py` drives the publish worker end to end (a real thread, drained with
  `Queue.join()`), a full queue, the narrowed `test_sink` except in both directions, and the
  `_mqtt_publish` connect-failure wrapping directly.

## [1.0.2] - 2026-09-25

Requires Jen 5.65.6 or later (`client_subnet_for_mac` in the plugin API).

### Fixed: a tracked client that changed subnet stayed filed under the old one

`pr_tracked.subnet_id` was written when a device was tracked and never updated. The page and untrack authorise on that stored value, so a user scoped to subnet A kept seeing and removing a client that now lived in subnet B. Every lease event the plugin handles now refreshes the stored subnet from Jen's `client_subnet_for_mac` (the one precedence: current lease, then reservation, then the device's last known subnet), so the device follows the client. A MAC with no known subnet keeps its last one. The same helper replaces the plugin's private lookup, which ordered the sources differently from Wake and Switch Port.

### Fixed: a device was declared offline while another lease was still active

Every `lease.expired` was treated as "the device left". A client that moved subnet, or holds a second lease, expires one lease and is still there. Offline now needs `lease.expired` **and** no remaining active lease for the MAC (state 0 and not past its expiry, Jen's own definition of active). The plugin also subscribes to `lease.ip_changed` now, which Jen reports when a client's address changes, and treats it as the client being present.

### Fixed: raw exception text on the page

A failed track, untrack, or sink change put the database's own error message into the page. The details go to Jen's log and the page shows a generic message. A sink's connection failure on **Send test** is still shown: it is the diagnostic about the integration the superadmin just configured, not an internal error.

### Changed

- `tools/test_plugin.py` covers the move A to B, the two-leases case, `lease.ip_changed`, the subnet refresh on every handled event, and the real `_has_active_lease` against a fake lease table.

## [1.0.1] - 2026-09-25

Requires Jen 5.65.2 or later (the `can_access_subnet` helper in the plugin API).

### Fixed: any admin could send every tracked device's state to a server they control

A sink receives every tracked client's MAC, label, IP, hostname and online state, for every device on every subnet, and the sink routes only checked "admin". An admin scoped to one subnet could add an HTTP or MQTT sink they control and from then on receive presence events for subnets they cannot see, and gained a general outbound HTTP and MQTT capability from the Jen host. A sink is a global integration with a credential, like an Alerts channel: adding, pausing or enabling, testing and removing one is now **superadmin-only**. Other admins see the list read-only.

### Fixed: routes authorised one thing and acted on another

The pattern this release names in every plugin: a route authorises on one thing (a subnet id the caller typed, or nothing for a by-id POST) and acts on another, or reads "no subnet" as "allow".

- **Tracking upserted over a hidden row.** The upsert overwrote `subnet_id`, so a scoped admin who knew the MAC of a device tracked in a subnet they cannot see could re-track it into their own and then see its state. The subnet is now the MAC's own (device, active lease, reservation), worked out here; an already-tracked MAC is authorised on its existing row first, and only its label can change, never its subnet.
- **"Track presence" from a row** authorised the `subnet_id` in the query string. It is ignored; the subnet comes from the MAC. The row action link no longer carries it, and the Track form no longer asks for an IP.
- **Untrack** by MAC checked nothing about the row; it now reads as not found unless the row's subnet is the caller's. A device with no subnet is for unrestricted callers only.

### Fixed: devices off the Jen host's own segment flapped offline

The neighbour pass reads `ip -4 neigh`, which only holds hosts on a segment the Jen host has an interface on. A tracked phone on any other subnet was never in it, so it "missed" three passes and went offline fifteen minutes after joining, and stayed there, because a renewal emits nothing. A pass now reads the host's own interface subnets (`ip -4 -o addr show`) and counts a miss only for a device on one of them. For every other device the state follows lease events alone, and the page says "lease-based" beside it. If the host's own subnets cannot be read, the pass counts nothing rather than guess. The README now states the limitation: a device that is not on a segment the Jen host is attached to is online from its lease and offline when the lease expires, not from a probe.

### Fixed: smaller things

- A bad MQTT port (`mqtt://host:abc`, `:99999`, `:0`) made the Add Sink form answer with a 500; the port is now read inside the validation, and the form shows its message.
- A `lease.new` for a device already recorded online (a renewal is reported the same way) re-published, re-audited and re-emitted an unchanged state. The lease path now acts only on a change, like the neighbour path.
- **Send test** published a retained Home Assistant discovery message for a made-up MAC, leaving a phantom entity behind. It now sends one non-retained message to `<prefix>/test` (an HTTP sink's body carries `"test": true`) and touches nothing else.
- An MQTT password with no user name broke MQTT-3.1.2-22 (the password flag must not be set without the user name flag); both the form and the packet builder refuse it.
- A `user:password@` password typed into an MQTT URL was stored in the URL column in clear. It is moved to the encrypted credential and the stored URL keeps only the user name.
- A webhook sink's bearer token was stored and then ignored; it is now sent, as it always was for a generic HTTP sink.
- Webhook and HTTP sinks accepted any URL scheme, including `file://`; they must be `http://` or `https://`.
- The MQTT client id was 25 characters (`jen-presence-` and 12 hex digits); MQTT 3.1.1 only guarantees 23. It is now `jen-pr-` and the 12 digits.
- The Home Assistant discovery message gains `json_attributes_topic`, so the attributes Presence already publishes show up on the entity.

### Changed

- The page's static styling moved out of inline `style=` attributes into its own `<style>` block; `tools/verify.py` now fails a template that carries one.
- The one dynamic `IN (...)` builder carries a one-line `# nosec B608` saying why it is safe.
- `tools/test_plugin.py` now runs the real routes, the neighbour pass, the lease path and the sink sender against fakes.

## [1.0.0] - 2026-09-24

### First release

Publishes tracked devices' online/offline state to Home Assistant, MQTT,
or any HTTP endpoint, so the house can react to a phone joining or
leaving the network. Only devices you explicitly track publish
anything, and each has two signals feeding its state: a Kea lease
event flips it immediately, and a periodic pass over the neighbour
table catches everything else — a single missed ARP probe cycle never
flips a device offline early, only three consecutive misses does.

MQTT is handled by this plugin's own minimal publish-only client, with
no external dependency: a fresh connection per transition, TLS
optional, an optional retained Home Assistant discovery message per
sink so a tracked device shows up as a `device_tracker` entity
automatically. Home Assistant webhooks and generic HTTP endpoints get
the same JSON body. Every sink can be sent a test message on demand,
and a failure records its own error without blocking any other sink
or queuing a retry.

A "Track presence" action is available straight from Jen's Lease and
Device rows. Everything respects Jen's subnet access control.

Built on Jen 5.57.0's plugin API v3 from the first commit: sprite
icons, a phone-ready rowlist, and no inline styles.
